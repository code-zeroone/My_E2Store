# -*- coding: utf-8 -*-
from Plugins.Extensions.IPTVPlayer.components.captcha_helper import CaptchaHelper
